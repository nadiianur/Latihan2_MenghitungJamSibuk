public class Mahasiswa extends Elemen {
    private int sks;
    public Mahasiswa(String nama, int sks) {
        super(nama);
        setSks (sks);
    }

    public void getJamSibuk(){
        System.out.println(getNama() + " adalah seorang mahasiswa dengan jam sibuk " + sks);
    }

    
    public int getSks (){
        return sks;
    }

    public void setSks(int NewSks){
        sks = NewSks*3; //
        
    }


    

    
}
