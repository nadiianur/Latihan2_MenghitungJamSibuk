public class Dosen extends Elemen{

    private int jumlahHariKerja;

    public Dosen(String nama, int jumlahHariKerja) {
        super(nama);
        setHariKerja (jumlahHariKerja);
    }

    public void getJamSibuk(){
        System.out.println(getNama() + " adalah seorang dosen dengan jam sibuk " + jumlahHariKerja);
    }

    
    public int getHariKerja (){
        return jumlahHariKerja;
    }

    public void setHariKerja(int newJumlahHariKerja){
        jumlahHariKerja = newJumlahHariKerja*8;
        
    }

    
}
