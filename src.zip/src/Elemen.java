public class Elemen{
    private String nama; 
    
    public Elemen (String nama){
        this.nama = nama;
    }

    public String toString(){
        return nama;
    }

    public String getNama (){
        return nama;
    }

    public void getJamSibuk(){
    }
}