public class Asdos extends Mahasiswa {
    private int jamNgasdos;
    public Asdos(String nama, int sks, int jamNgasdos) {
        super(nama,sks);
        setJamNgasdos (jamNgasdos);
        
    }

    public void getJamSibuk(){
        System.out.println(getNama() + " adalah seorang asdos dengan jam sibuk " + jamNgasdos);
    }

    
    public int getJamNgasdos (){
        return jamNgasdos;
    }

    public void setJamNgasdos(int newJamNgasdos){
        jamNgasdos = getSks() + newJamNgasdos; //
        
    }


}
