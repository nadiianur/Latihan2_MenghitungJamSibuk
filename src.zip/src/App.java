public class App {
    public static void main(String[] args) throws Exception {
        Dosen Dsatu = new Dosen("Raja OP Damanik", 5);
        Dosen Ddua = new Dosen("Nivotko", 3);
        Mahasiswa MhSatu = new Mahasiswa("Firman", 20);
        Mahasiswa MhDua = new Mahasiswa("Nid to pass this sem", 23);
        Mahasiswa MhTiga = new Asdos("Fairuzikun", 24, 1);
        Mahasiswa MhEmpat =  new Asdos("Angel-chan", 21, 1);

        MhTiga.getJamSibuk();
        Dsatu.getJamSibuk();
        MhEmpat.getJamSibuk();
        MhSatu.getJamSibuk();
        MhDua.getJamSibuk();
        Ddua.getJamSibuk();

        

    }
}
